
console.log('Script chargé et exécuté.');
// Votre code ici

let cards = document.querySelectorAll('.premiumCard');

// Fonction pour appliquer l'effet lumineux à une carte
function applyHighlight(card, x, y) {
    card.style.setProperty('--x', x + 'px');
    card.style.setProperty('--y', y + 'px');
    card.classList.add('highlight');
}

// Fonction pour retirer l'effet lumineux d'une carte
function removeHighlight(card) {
    card.classList.remove('highlight');
}

// Gestionnaire d'événement pour la grille de cartes
document.querySelector('.premiumCards').addEventListener('mousemove', function (e) {
    // console.log("moove")
    let mouseX = e.pageX;
    let mouseY = e.pageY;

    // Parcours de toutes les cartes pour déterminer celles qui doivent avoir l'effet lumineux
    cards.forEach(card => {
        let rect = card.getBoundingClientRect();
        let cardX = rect.left + rect.width / 2;
        let cardY = rect.top + rect.height / 2;
        let distance = Math.sqrt(Math.pow(mouseX - cardX, 2) + Math.pow(mouseY - cardY, 2));

        if (distance < 400) { // Augmentation de la distance pour l'effet
            applyHighlight(card, e.pageX - rect.left, e.pageY - rect.top);
            console.log("highlight")
        } else {
            removeHighlight(card);
        }
    });
});

// Gestionnaire d'événement pour réinitialiser l'effet lorsque la souris quitte la grille de cartes
document.querySelector('.premiumCards').addEventListener('mouseleave', function () {
    cards.forEach(card => {
        removeHighlight(card);
    });
});