// pages/index.js ou pages/offres.js
import React, { useEffect } from 'react';
import './offres.css';
import Script from 'next/script';

function App() {


  return (
    <div className="premiumCards">
      <Script
        src="/script.js"
        strategy="afterInteractive" // Assurez-vous que le script est chargé après l'interaction avec la page
      />
      <br /><br /><br />
      <div className="premiumCard" style={{ "--clr": "#0f0" }}>
        <h2>Offre Gratuite</h2>
        <ul>
          <li>accés a plus de 100 commandes</li>
          <li>Un support disponible 24/7</li>
          <li>Différence 3</li>
          <li>suce moiiiiiiiiiiiiiiiiiiiiiiiiii</li>
          <li>Différence 5</li>
          <li>jfo</li>
          <li>ff</li>
          <li>JOJO'S</li>
          <li>f</li>
          <li>f</li>
          <li>f</li>
        </ul>
      </div>
      <div className="premiumCard" style={{ "--clr": "#ff0" }}>
        <h2>Offre 2</h2>
        <ul>
          <li>Différence 1</li>
          <li>Différence 2</li>
          <li>Différence 3</li>
          <li>Différence 4</li>
          <li>Différence 5</li>
          <li>kj</li>
          <li>OHHHHHH JE VAIS</li>
          <li>PAYEEEE</li>
          <li>PAYE</li>
          <li>PAYE maintenant</li>
          <li>PAYE MAINTEANT</li>
        </ul>
      </div>
      <div className="premiumCard" style={{ "--clr": "#00f" }}>
        <h2>Offre 3</h2>
        <ul>
          <li>Différence 1</li>
          <li>Différence 2</li>
          <li>Différence 3</li>
          <li>Différence 4</li>
          <li>Différence 5</li>
          <li>kj</li>
          <li>OHHHHHH JE VAIS</li>
          <li>PAYEEEE</li>
          <li>PAYE</li>
          <li>PAYE maintenant</li>
          <li>PAYE MAINTEANT</li>
        </ul>
      </div>
      <div className="premiumCard" style={{ "--clr": "#f00" }}>
        <h2>Offre 4</h2>
        <ul>
          <li>Différence 1</li>
          <li>Différence 2</li>
          <li>Différence 3</li>
          <li>Différence 4</li>
          <li>Différence 5</li>
          <li>kj</li>
          <li>OHHHHHH JE VAIS</li>
          <li>PAYEEEE</li>
          <li>PAYE</li>
          <li>PAYE maintenant</li>
          <li>PAYE MAINTEANT</li>
        </ul>
      </div>
      <div className="premiumCard" style={{ "--clr": "rgb(8, 241, 109)" }}>
        <h2>Offre 4</h2>
        <ul>
          <li>Différence 1</li>
          <li>Différence 2</li>
          <li>Différence 3</li>
          <li>Différence 4</li>
          <li>Différence 5</li>
          <li>kj</li>
          <li>OHHHHHH JE VAIS</li>
          <li>PAYEEEE</li>
          <li>PAYE</li>
          <li>PAYE maintenant</li>
          <li>PAYE MAINTEANT</li>
        </ul>
      </div>
    </div>
  );
}

export default App;
