import React from "react";
import { Card, CardHeader, CardBody, Image, Button, Link } from "@nextui-org/react";

const CardComponent = ({ title, description, members, link }) => (
  <Card className="py-4 w-60 mx-2 flex flex-col items-center">
    <CardHeader className="pb-0 pt-2 px-4 flex-col items-center text-center">
      <p className="text-tiny uppercase font-bold">{title}</p>
      <small className="text-default-500">{description}</small>
      <h4 className="font-bold text-large">{members}</h4>
    </CardHeader>
    <CardBody className="overflow-visible py-2 flex justify-center">
      <Button as={Link} color="default" size="large" variant="faded" href={link}>
        Rejoindre ce serveur
      </Button>
    </CardBody>
  </Card>
);

export default function Serveurs() {
  return (
    <div className="flex flex-wrap justify-center">
      <CardComponent 
        title="Ils nous font déjà confiance, faites le pas"
        description="10 serveurs Premium"
        members="🌉 彡 𝑯𝑽𝑵 𝙍𝙤̂𝙡𝙚𝙥𝙡𝙖𝙮 | 𝗟.𝗔 - 12422 membres"
        link="https://discord.gg/Wb7UpyASF9"
      />
      <CardComponent 
        title="Rejoignez notre communauté active"
        description="8 serveurs Premium"
        members="🌉 彡 𝑯𝑽𝑵 𝙍𝙤̂𝙡𝙚𝙥𝙡𝙖𝙮 | 𝗡𝗬 - 8422 membres"
        link="https://discord.gg/xyz123"
      />
      <CardComponent 
        title="Découvrez nos nouveaux serveurs"
        description="5 serveurs Premium"
        members="🌉 彡 𝑯𝑽𝑵 𝙍𝙤̂𝙡𝙚𝙥𝙡𝙖𝙮 | 𝗖𝗛𝗜 - 6522 membres"
        link="https://discord.gg/abc456"
      />
      
    </div>
  );
}
