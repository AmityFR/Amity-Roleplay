import React from "react";
import { Card, CardHeader, CardBody, CardFooter, Image, Button, Chip } from "@nextui-org/react";

export default function Cards() {
    return (
        <div className="max-w-[900px] gap-2 grid grid-cols-12  mx-auto">
            <Card className="col-span-12 sm:col-span-4 h-[300px]">
                <CardHeader className="absolute z-10 top-1 flex-col !items-start">
                    <p className="text-tiny text-white/60 uppercase font-bold">Justice</p>
                    <h4 className="text-white font-medium text-large">Ne perdez plus de temps </h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card background"
                    className="z-0 w-full h-full object-cover"
                    src="https://img.gta5-mods.com/q75/images/palais-de-justice/473767-face.PNG"
                />
            </Card>
            <Card className="col-span-12 sm:col-span-4 h-[300px]">
                <CardHeader className="absolute z-10 top-1 flex-col !items-start">
                    <p className="text-tiny text-white/60 uppercase font-bold">Le vol dans le sang</p>
                    <h4 className="text-white font-medium text-medium">Braquages sans limites</h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card background"
                    className="z-0 w-full h-full object-cover"
                    src="https://nextui.org/images/card-example-3.jpeg"
                />
            </Card>
            <Card className="col-span-12 sm:col-span-4 h-[300px]">
                <CardHeader className="absolute z-10 top-1 flex-col !items-start">
                    <p className="text-tiny text-white/60 uppercase font-bold">Qui as dit que c'était légale</p>
                    <h4 className="text-white font-medium text-large">Des ajouts afin d'améliorer le réalisme gameplay</h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card background"
                    className="z-0 w-full h-full object-cover"
                    src="https://nextui.org/images/card-example-2.jpeg"
                />
            </Card>
        </div>
    );
}
