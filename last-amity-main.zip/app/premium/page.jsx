"use client";
import "./premium.css";

import {
    Button,
    Chip,
    Link,
    Card,
    Image,
    CardFooter
} from "@nextui-org/react";

import Script from "next/script";

import Cards from "./cards";
import Serveurs from "./Serveurs";
import Offres from "./offres"
import { useEffect } from "react";

export default function PremiumPage() {

    // useEffect(() => {
    //     console.log('Script chargé et exécuté.');
    //     // Votre code ici
        
    //     let cards = document.querySelectorAll('.card');
        
    //     // Fonction pour appliquer l'effet lumineux à une carte
    //     function applyHighlight(card, x, y) {
    //         card.style.setProperty('--x', x + 'px');
    //         card.style.setProperty('--y', y + 'px');
    //         card.classList.add('highlight');
    //     }
        
    //     console.log('Script chargé et exécuté.');
    //     // Fonction pour retirer l'effet lumineux d'une carte
    //     function removeHighlight(card) {
    //         card.classList.remove('highlight');
    //     }
        
    //     console.log('Script chargé et exécuté.');
    //     // Gestionnaire d'événement pour la grille de cartes
    //     document.querySelector('.container').addEventListener('mousemove', function (e) {
    //         let mouseX = e.pageX;
    //         let mouseY = e.pageY;
            
    //         // Parcours de toutes les cartes pour déterminer celles qui doivent avoir l'effet lumineux
    //         cards.forEach(card => {
    //             let rect = card.getBoundingClientRect();
    //             let cardX = rect.left + rect.width / 2;
    //             let cardY = rect.top + rect.height / 2;
    //             let distance = Math.sqrt(Math.pow(mouseX - cardX, 2) + Math.pow(mouseY - cardY, 2));
                
    //             if (distance < 400) { // Augmentation de la distance pour l'effet
    //                 applyHighlight(card, e.pageX - rect.left, e.pageY - rect.top);
    //             } else {
    //                 removeHighlight(card);
    //             }
    //         });
    //     });
        
    //     console.log('Script chargé et exécuté.');
    //     // Gestionnaire d'événement pour réinitialiser l'effet lorsque la souris quitte la grille de cartes
    //     document.querySelector('.container').addEventListener('mouseleave', function () {
    //         cards.forEach(card => {
    //             removeHighlight(card);
    //         });
    //     });
    //     console.log('Script chargé et exécuté.');
        
    // }, []);

    return (
        <div>

            <main>
                <div className="title my-20">
                    <h1>VIVEZ UNE EXPÉRIENCE SANS LIMITES</h1>
                </div>
                <div>
                    <div className="flex flex-col md:flex-row justify-center items-center">
                        <div className="flex flex-col md:w-1/2 p-5">
                            <h2 className="text-2xl font-bold">Amity RôlePlay, un bot RP conçu pour vous et qui progresse avec vous.</h2>
                            <p className="text-lg mt-5">Amity RolePlay est un bot Discord qui vous permet de créer des personnages, des lieux, des objets et des quêtes pour votre serveur RP. Il est conçu pour vous aider à gérer votre serveur RP et à créer des expériences RP uniques pour vos joueurs.</p>
                            <div className="mt-5">
                                <Button as={Link} color="default" size="large" variant="faded" href="https://discord.gg/Wb7UpyASF9" >Support Discord</Button>
                                <Button as={Link} color="secondary" size="large" variant="ghost" className="mx-5" href="#buy">Commencer</Button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="content-center text-center mx-auto inline-block">
                </div>
                <div id="advantages">
                    <Serveurs />
                    <Cards />
                </div>
                <Offres />
            </main>
        </div>
    );
}