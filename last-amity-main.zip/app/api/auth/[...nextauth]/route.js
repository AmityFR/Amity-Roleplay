import NextAuth from 'next-auth';
import DiscordProvider from 'next-auth/providers/discord';
import { cookies } from 'next/headers';
import Cookies from 'js-cookie';

export const authOptions = {
    providers: [
        DiscordProvider({
            clientId: process.env.DISCORD_CLIENT_ID,
            clientSecret: process.env.DISCORD_CLIENT_SECRET,
            authorization: {
                params: {
                    scope: 'identify email guilds.join guilds',
                },
            },
        }),
    ],
    callbacks: {
        async jwt({ token, user, account }) {
            if (account) {
                token.accessToken = account.access_token;
                token.id = user.id;
            }
            return token;
        },
        async session({ session, token }) {
            session.accessToken = token.accessToken;
            session.id = token.id;

            // Utilisation de cookies de Next.js
            const cookieOptions = {
                maxAge: 60 * 60 * 24 * 7, // 1 semaine
                path: '/',
                httpOnly: true, // Assurez-vous que le cookie est accessible uniquement par le serveur
                secure: process.env.NODE_ENV === 'production', // Utilisez "secure" uniquement en production
            };

            // Définir le cookie via les en-têtes de réponse
            cookies().set('session', JSON.stringify(session), cookieOptions);

            // Cookies.set('session', JSON.stringify(session));

            return session;
        },
    },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
