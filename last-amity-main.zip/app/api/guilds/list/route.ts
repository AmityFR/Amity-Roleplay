import axios from "axios";
import { NextResponse, NextRequest } from "next/server";
import getUserServers from "../../../utils/functions/getUserServers";
import connectToDatabase from "../../../utils/db";
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// mettre le token en authorization par défaut
axios.defaults.headers.common['Authorization'] = `Bot ${process.env.NEXT_PUBLIC_TOKEN}`;

export async function GET(request: NextRequest) {
    const searchParams = request.nextUrl.searchParams;
    if (!searchParams) return NextResponse.json({ error: "Missing required parameters" });
    const accessToken = searchParams.get('accessToken');
    const id = searchParams.get('id');

    if (!accessToken || !id) return NextResponse.json({ error: "Missing required parameters" });

    try {
        const userServers = await getUserServers(accessToken);
        const db = await connectToDatabase();
        const collection = db.collection("guilds");
        const guilds = await collection.find({ guildId: { $in: userServers.map(server => server.id) } }).toArray();

        const memberPromises = userServers.map(async server =>
            await wait(1500).then(async () =>
                await axios.get(`https://discord.com/api/v9/guilds/${server.id}/members/${id}`)
                    .then(response => ({ serverId: server.id, data: response.data }))
                    .catch(() => ({ serverId: server.id, data: null }))
            )
        );

        const members = await Promise.all(memberPromises);

        userServers.forEach(server => {
            const member = members.find(m => m.serverId === server.id)?.data;
            const guild = guilds.find(g => g.guildId === server.id);

            if (member) {
                server.botIn = true;
                const staffRole = guild?.hierarchie.find(role => role.name === "Staff");

                if (staffRole) {
                    server.staff = member.roles.includes(staffRole.id);
                }
                const permissions = BigInt(server.permissions); // Convert permissions to BigInt
                server.admin = (permissions & BigInt(8)) === BigInt(8);
            } else {
                server.botIn = false;
                server.staff = false;
                server.admin = false;
            }
        });

        return NextResponse.json({ servers: userServers });
    } catch (error) {
        return NextResponse.json({ error: error.message });
    }
}
