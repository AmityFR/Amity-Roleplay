"use server";
import connectToDatabase from "../../../utils/db";
import { NextResponse, NextRequest } from "next/server";

/*
* @param {NextRequest} req
* @param {NextResponse} res
* @params

*/

export async function GET(req: NextRequest, res: NextResponse) {
    // Utiliser l'API URL pour extraire les paramètres de l'URL
    const url = new URL(req.url);
    const id = url.pathname.split('/').pop(); // Récupère l'id à partir du chemin de l'URL

    if (!id) {
        return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    const db = await connectToDatabase();

    // Utiliser async/await pour les requêtes de la base de données
    try {
        const guild = await (await db.collection("guilds")).findOne({ guildId: id });
        const persos = await (await db.collection("persos")).find({ guildId: id });
        const banks = await (await db.collection("banks")).find({ guildId: id });
        const cars = await (await db.collection("cars")).find({ guildId: id });
        const houses = await (await db.collection("houses")).find({ guildId: id });
        const companies = await (await db.collection("companies")).find({ guildId: id });

        if (!guild) {
            return NextResponse.json({ error: "Guild not found" }, { status: 404 });
        }

        const drogues = guild.settings?.drogues?.types || [];
        const braquages = guild.settings?.braquages || [];

        const premium = await (await db.collection("codes")).findOne({ "redeemedBy.guildId": id }) || null;

        const returns = {
            guild: guild,
            persos: await persos.toArray(),
            banks: await banks.toArray(),
            cars: await cars.toArray(),
            houses: await houses.toArray(),
            companies: await companies.toArray(),
            drogues: drogues,
            braquages: braquages,
            premium: premium
        };

        // console.log(returns);

        return NextResponse.json(returns);
    } catch (error) {
        console.error("Error fetching data:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
