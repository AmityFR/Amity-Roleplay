import { Inter } from "next/font/google";
import "./globals.css";
import HomeNavBar from "./components/nav/main/navbar"
import Amity from "/public/amity_logo.png"
import SessionProviderWrapper from "./components/SessionProviderWrapper";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "🌐 | Amity Web",
  description: "Bot RP Amity RôlePlay Bot. AmityRP est un bot RôlePlay dédié aux utilisateurs console principalement qui souhaitent implémenter le RôlePlay par le biais de discord !",
  lang: "fr",
  image: Amity // Assurez-vous que ce chemin est correct
};

export default function RootLayout({ children }) {
  return (
    <html className="dark">
      <head>
        <link rel="icon" href="/amity_logo.png" type="image/png" />
      </head>
      <body>
        <SessionProviderWrapper>
          <HomeNavBar />
          <div className={inter.className}>
            {children}
          </div>
        </SessionProviderWrapper>
      </body>
    </html>
  );
}
