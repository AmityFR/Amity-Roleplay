"use client";

import { signOut } from 'next-auth/react';
import { Button } from "@nextui-org/react"
export default function Login() {
    return (
        <div className='text-center'>
            <br /><br /><br /><br />
            <h1 className='mt-[5%] text-5xl'>Déconnection</h1>
            <br /><br />
            <Button
                variant='faded'
                color='default'
                className='w-[300px] h-[60px]'
                onClick={() => signOut({ callbackUrl: "/" })}>
                Se déconnecter de Discord
            </Button>
        </div>
    );
}
