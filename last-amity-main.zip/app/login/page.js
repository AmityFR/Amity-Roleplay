"use client";

import { signIn } from 'next-auth/react';
import { Button } from "@nextui-org/react"
export default function Login() {
    return (
        <div className='text-center'>
            <br /><br /><br /><br />
            <h1 className='mt-[5%] text-5xl'>Se connecter avec Discord</h1>
            <br /><br />
            <Button
                variant='faded'
                color='default'
                className='w-[300px] h-[60px]'
                onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}>
                Se connecter avec Discord
            </Button>
        </div>
    );
}
