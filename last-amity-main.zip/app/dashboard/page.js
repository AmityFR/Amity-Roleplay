import { Button, Link, Divider } from "@nextui-org/react";

export default function DashboardPage() {
    return (
        <>
            <h1>Liste des tes serveurs</h1>
            <br /><br /><br />

            <Button
                as={Link}
                varient="faded"
                color="default"
                href="/servers"
            >
                Liste des serveurs
            </Button>
        </>
    )
}