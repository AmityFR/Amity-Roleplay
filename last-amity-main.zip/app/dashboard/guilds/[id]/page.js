"use client"
import { useEffect, useState } from "react";
import getCookie from "../../../utils/getCookie";
import getServer from "../../../utils/getServer";
import { useParams } from 'next/navigation';
import {
    Card,
    Button,
    Chip,
    Divider,
    Avatar
} from "@nextui-org/react"

import "./guildsPage.css";
import axios from "axios";

export default function GuildPage() {
    const { id } = useParams();
    const [server, setServer] = useState({});
    const [stats, setStats] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const asF = async () => {
            const serverInfo = await getServer(id);
            setServer(serverInfo);
            const stats = await axios.get(`/api/stats/${id}`, {})
                .then((result) => { return result.data; }).catch((err) => { console.error(err); });
            console.log(stats)
            setStats(stats);
            setLoading(false);
        }
        asF();

    }, []);

    if (loading) {
        return (
            <div>
                {loading && <h1>Chargement du serveur et des Statistiques ... Ce processus peux se montrer long.</h1>}
            </div>
        )
    }


    function handleSort() {
        let sorted = stats.banks.sort((a, b) => {
            return b.money - a.money;
        });

        let sortedWithPerso = sorted.map(bank => {
            let perso = stats.persos.find(p => p.id === bank.id && p.persoId === Number(bank.persoId));
            console.log(perso)
            return `${perso && perso.idCard.have ? `${perso.idCard.firstName} ${perso.idCard.lastName}` : "Personne inconnu"} : ${bank.money}$`;
        }).slice(0, 15); // Limiter à 15 éléments

        return sortedWithPerso;
    }

    return (
        <div className="text-center justify-center items-center content-center mx-auto">
            <Button
                color="danger"
            >
                <a href="/servers">Retour aux serveurs</a>
            </Button>
            <br /><br />
            <h1 className="title">DASHBOARD DU SERVEUR</h1>
            <br />
            <h2 className="text-2xl">{server.name}</h2>
            <br />
            <small>{server.description}</small>
            <br /><br />
            <div>
                {/* <img
                    className="rounded-[10px] mx-auto"
                    src={server.icon ? `https://cdn.discordapp.com/icons/${server.id}/${server.icon}.${server.icon.startsWith("a") ? "gif" : "png"}` : "/discord-default.png"}
                    width={256}
                    height={256}
                /> */}

                <Avatar
                    src={server.icon ? `https://cdn.discordapp.com/icons/${server.id}/${server.icon}.${server.icon.startsWith("a") ? "gif" : "png"}` : "/discord-default.png"}
                    className="w-[256px] h-[256px] mx-auto rounded-[25px] transition-transform ring-offset-background ring-offset-4 ring-default ring-4"
                >

                </Avatar>

            </div>
            <br /><br />
            <Card className="faded-card mx-auto">
                <h2>Configurations</h2>
                <small>Toutes vos configurations, en plus rapide et simple !</small>
                <br />
                <ul>
                    <li>
                        <Button
                            variant="ghost"
                            color="primary"
                            className="text-white"
                        >
                            Configuration des rôles et salons
                        </Button><br />
                        <small>⚠️ Etape obligatoire</small>
                    </li>
                    <br />
                    <li>
                        <Button
                            variant="ghost"
                            color="primary"
                            className="text-white"
                        >
                            Configuration des braquages
                        </Button>
                    </li>
                    <br />
                    <li>
                        <Button
                            variant="ghost"
                            color="primary"
                            className="text-white"
                        >
                            Configuration des drogues
                        </Button>
                    </li>
                    <br />
                    <li>
                        <Button
                            variant="ghost"
                            color="primary"
                            className="text-white"
                        >
                            Configuration des panels
                        </Button>
                    </li>
                    <br />
                    <li>
                        <Button
                            variant="ghost"
                            color="primary"
                            className="text-white"
                        >
                            Configuration des rôles
                        </Button>
                    </li>
                </ul>
                <br />
            </Card>
            <br /><br />
            <div>
                <Card className="mx-auto faded-card text-left">
                    <h2 className="text-center">Statistiques du serveur</h2>
                    <br />
                    <div>
                        <p>Nombres de personnages : {stats.persos.length}</p>
                        <Divider orientation='horizontal' className='my-3' />
                        <p>Nombres de comptes bancaire : {stats.banks.length}</p>
                        <Divider orientation='horizontal' className='my-3' />
                        <p>Nombres de véhicules (cartes grises) : {stats.cars.length}</p>
                        <Divider orientation='horizontal' className='my-3' />
                        <p>Nombre d'habitations : {stats.houses.length}</p>
                    </div>
                </Card>
            </div>
            <br /><br /><br />
            <div>
                <Card className="mx-auto faded-card text-left">
                    <h2 className="text-center">Classement du compte bancaire le plus riche </h2>
                    <br />
                    <div>
                        <Divider orientation='horizontal' className='my-3' />
                        {handleSort().map((bank, index) => {
                            return (
                                <div key={index}>
                                    <p color="success"><b className="text-[#a3a3b6] mr-3">{index + 1}. </b> {bank}</p>
                                    <Divider orientation='horizontal' className='my-3' />
                                </div>
                            )
                        })}
                    </div>
                </Card>
            </div>




            <br /><br /><br /><br /><br /><br /><br /><br /><br />
            <br /><br /><br /><br /><br /><br /><br /><br /><br />
            <br /><br /><br /><br /><br /><br /><br /><br /><br />
        </div>
    )
}