"use server"

import axios from "axios";

export default async function getServer(id) {
    return axios.get(`https://discord.com/api/v10/guilds/${id}`, {
        headers: {
            Authorization: `Bot ${process.env.NEXT_PUBLIC_TOKEN}`,
        },
        params: {
            with_counts: true,
        },
    }).then((res) => { return res.data; }).catch((err) => { return });
}