"use server"
import { cookies } from 'next/headers';

export default async function getCookie(name) {
    const cookie = cookies().delete(name);
    return true;
}
