const axios = require('axios');

export default function getUserServers(access_token) {
    return axios({
        method: "get",
        url: "https://discord.com/api/v10/users/@me/guilds",
        headers: {
            "Authorization": `Bearer ${access_token}`
        }
    }).then((res) => {
        return res.data;
    }).catch((e) => {
        console.error(e);
        return Promise.reject(e.response);
    });
}