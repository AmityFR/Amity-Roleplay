const axios = require('axios');

export default function joinServer(serverId: string, accessToken: string) {
    axios({
        method: "get",
        url: "https://discord.com/api/v10/users/@me",
        headers: {
            "Authorization": `Bearer ${accessToken}`
        }
    }).then((res: any) => {
        if (res.status === 200) {
            axios.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
            axios.put(`https://discord.com/api/v9/guilds/${serverId}/members/${res.data.id}`, {
                'access_token': accessToken
            })
                .then(response => {
                    console.log(`User added to guild successfully!`);
                })
                .catch(error => {
                    console.error(`Error adding user to guild: ${error}`);
                });
        }
    }).catch((e: any) => {
        return e.response;
    })

}