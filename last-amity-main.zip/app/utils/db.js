import { MongoClient } from 'mongodb';

let cachedDb = null;

async function connectToDatabase() {
    if (cachedDb) {
        return cachedDb;
    }

    const client = await MongoClient.connect(process.env.NEXT_PUBLIC_URI_MONGODB, {});

    const db = await client.db(new URL(process.env.NEXT_PUBLIC_URI_MONGODB).pathname.substr(1));

    cachedDb = db;
    return db;
}

export default connectToDatabase;
