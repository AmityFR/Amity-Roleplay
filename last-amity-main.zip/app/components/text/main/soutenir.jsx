import styles from "./soutenir.css";
export default function Soutient() {
  return (
    <center>
      <div>
        <h2>Vous aimez le projet et vous souhaitez nous soutenir,</h2>
        <h2>c'est juste en dessous</h2>
        <br />
        <a href="https://top.gg/bot/1199327286625832990">
          <img src="https://top.gg/api/widget/1199327286625832990.svg" />
        </a>
        <br />
        <h2>Merci de votre soutien</h2>
      </div>
    </center>
  );
}
