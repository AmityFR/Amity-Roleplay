import "./soustitres.css";

export default function Soustitres() {
  return (
    <center>
      <div className="container">
        <h2 className="title mx-5% text-center">Amity RolePlay, un bot RP conçu pour vous et qui progresse avec vous.</h2>
      </div>
    </center>
  );
}