import React from "react";
import "./amity.css";

export default function GradientText() {
  return (
    <div className="bvntext">
      <h1 className="my-20">BIENVENUE SUR AMITY</h1>
    </div>
  );
}
