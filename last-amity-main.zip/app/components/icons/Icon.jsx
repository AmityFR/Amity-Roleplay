import { IconContext } from "react-icons";



export default function IconProperties({ icon }) {
    return (
        <IconContext.Provider
            value={{ color: 'blue', size: '50px' }}
        >
            <div>
                {icon}
            </div>
        </IconContext.Provider>
    );
}