import React from "react";
import { Card, CardHeader, CardBody, CardFooter, Image, Button } from "@nextui-org/react";

export default function Cards() {
    return (
        <center>
        <div className="max-w-[900px] gap-2 grid grid-cols-12 grid-rows-2 px-8">
            <Card className="col-span-12 sm:col-span-4 h-[300px]">
                <CardHeader className="absolute z-10 top-1 flex-col !items-start">
                    <p className="text-tiny text-white/60 uppercase font-bold">Un Bot qui en as dans le ventre </p>
                    <h4 className="text-white font-medium text-large">Découvrez AMITY, un BOT qui vous surprendra</h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card background"
                    className="z-0 w-full h-full object-cover"
                    src="https://nextui.org/images/card-example-4.jpeg"
                />
            </Card>
            <Card className="col-span-12 sm:col-span-4 h-[300px]">
                <CardHeader className="absolute z-10 top-1 flex-col !items-start">
                    <p className="text-tiny text-white/60 uppercase font-bold">Faites le pas</p>
                    <h4 className="text-white font-medium text-large">Faites nous confiance comme plus de 1800 serveurs</h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card background"
                    className="z-0 w-full h-full object-cover"
                    src="https://nextui.org/images/card-example-3.jpeg"
                />
            </Card>
            <Card className="col-span-12 sm:col-span-4 h-[300px]">
                <CardHeader className="absolute z-10 top-1 flex-col !items-start">
                    <p className="text-tiny text-white/60 uppercase font-bold">Options</p>
                    <h4 className="text-white font-medium text-large">Jamais fini de s'améliorer grâce à vous </h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card background"
                    className="z-0 w-full h-full object-cover"
                    src="https://nextui.org/images/card-example-2.jpeg"
                />
            </Card>
            <Card isFooterBlurred className="w-full h-[300px] col-span-12 sm:col-span-5">
                <CardHeader className="absolute z-10 top-1 flex-col items-start">
                    <p className="text-meduim text-white/60 uppercase font-bold">Nouveau</p>
                    <h4 className="text-white font-medium text-2xl">Découvrez les nouvelles commandes telles que /tacos</h4>
                </CardHeader>
                <Image
                    removeWrapper
                    alt="Card example background"
                    className="z-0 w-full h-full object-cover"
                    src="https://th.bing.com/th/id/OIP.uKYE9S3LxEVVWCT5o8uSiQHaD2?w=327&h=180&c=7&r=0&o=5&pid=1.7"
                />
            </Card>

            
        </div> 
        </center>
    );
}
