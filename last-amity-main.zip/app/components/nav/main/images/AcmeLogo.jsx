import React from "react";
export const AcmeLogo = () => (
    <img src="/amity_logo.png" alt="" width="36"/>
);
