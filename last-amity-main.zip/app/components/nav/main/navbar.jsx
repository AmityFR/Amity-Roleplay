"use client";

import React from "react";
import {
    Navbar,
    NavbarBrand,
    NavbarMenuToggle,
    NavbarMenuItem,
    NavbarMenu,
    NavbarContent,
    NavbarItem,
    Link,
    Button,
    Dropdown,
    DropdownTrigger,
    DropdownMenu,
    DropdownItem,
    DropdownSection,
    Avatar,
    Card
} from "@nextui-org/react";
import { AcmeLogo } from "./images/AcmeLogo"; // Ensure this path is correct
import "./navbar.css";
import { signIn, signOut, useSession } from 'next-auth/react';
import { useEffect } from 'react';
import getCookie from "../../../utils/getCookie"
import deleteCookie from "../../../utils/deleteCookie";
export default function App() {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);
    const [loggedIn, setLoggedIn] = React.useState(false);
    const [user, setUser] = React.useState({});


    useEffect(() => {
        const fa = async () => {
            const sessionCookie = await (await getCookie('session'));
            if (sessionCookie) {
                setLoggedIn(true);
                setUser(JSON.parse(sessionCookie.value).user);
            } else {
                setLoggedIn(false);
            }
        }

        fa();
    }, [])



    return (
        <div className="app-container">
            <Navbar
                isMenuOpen={isMenuOpen}
                onMenuOpenChange={setIsMenuOpen}
                className="navbar fixed"
                isBordered
                maxWidth="full"
                isBlurred={true}
            >
                {/* Mobile Layout */}
                <NavbarContent className="sm:hidden" justify="end">
                    <NavbarMenuToggle aria-label={isMenuOpen ? "Fermer le menu" : "Ouvrir le menu"} />
                    <NavbarBrand>
                        <a href="/" className="flex items-center">
                            <AcmeLogo />
                            <p className="font-bold text-inherit">AMITY</p>
                        </a>
                    </NavbarBrand>
                    <div className="flex items-center">
                        <NavbarItem>
                            <Button
                                as={Link}
                                href="/premium"
                                color="secondary"
                                variant="faded"
                                className="star-button mr-3 min-w-1"

                            >
                                ✨
                            </Button>
                        </NavbarItem>
                        <NavbarItem>
                            {!loggedIn ? (
                                <Button as={Link} color="default" onClick={() => signIn("discord")} variant="ghost">
                                    Connexion
                                </Button>
                            ) : (
                                <Avatar
                                    isBordered
                                    as="button"
                                    className="transition-transform"
                                    name={user.name}
                                    size="sm"
                                    radius="md"
                                    src={user.image}
                                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                                />
                            )}
                        </NavbarItem>
                    </div>
                </NavbarContent>

                {/* Desktop Layout */}
                <NavbarContent className="hidden sm:flex justify-between" style={{ width: '100%' }} justify="center">
                    <div className="flex items-center gap-4">
                        <NavbarBrand >
                            <a href="/" className="flex items-center">
                                <AcmeLogo />
                                <p className="font-bold text-inherit">AMITY</p>
                            </a>
                        </NavbarBrand>
                        <NavbarItem isActive>
                            <Link color="foreground" href="/">
                                Accueil
                            </Link>
                        </NavbarItem>
                        <NavbarItem>
                            <Link href="/dashboard" color="foreground">
                                Dashboard
                            </Link>
                        </NavbarItem>
                        <Dropdown>
                            <NavbarItem>
                                <DropdownTrigger>
                                    <Link
                                        className="p-0 bg-transparent data-[hover=true]:bg-transparent cursor-pointer"
                                        radius="sm"
                                        color="foreground"
                                    >
                                        Catégories
                                    </Link>
                                </DropdownTrigger>
                            </NavbarItem>
                            <DropdownMenu variant="faded" aria-label="Dropdown menu with description">
                                <DropdownSection title="Dashboard">
                                    <DropdownItem
                                        key="Dashboard"
                                        className="text-danger"
                                        color="secondary"
                                        description="Accéder à votre tableau de bord"
                                        href="/dashboard"
                                    >
                                        Dashboard
                                    </DropdownItem>
                                    <DropdownItem
                                        key="Mon profil "
                                        className="text-danger"
                                        color="warning"
                                        description="Voir votre profil/personnages"
                                    >
                                        Mon profile
                                    </DropdownItem>
                                </DropdownSection>
                                <DropdownSection title="Informations">
                                    <DropdownItem
                                        key="new"
                                        description="Une question ? Un problème ? Rejoignez notre support Discord."
                                    >
                                        Support Discord
                                    </DropdownItem>
                                    <DropdownItem
                                        key="copy"
                                        description="Invitez et ajoutez le bot sur votre serveur !"
                                    >
                                        Inviter le bot
                                    </DropdownItem>
                                </DropdownSection>
                            </DropdownMenu>
                        </Dropdown>
                    </div>
                    <div className="flex items-center gap-4 ml-auto">
                        <NavbarItem>
                            <Button as={Link} href="/premium" color="secondary" variant="faded">
                                Premium ✨
                            </Button>
                        </NavbarItem>
                        <NavbarItem>
                            {!loggedIn ? (
                                <Button as={Link} color="default" variant="ghost" onClick={() => signIn("discord", {callbackUrl: "/"})}>
                                    Connexion
                                </Button>
                            ) : (
                                <Dropdown placement="bottom-end" className="hidden sm:flex">
                                    <DropdownTrigger>
                                        <Avatar
                                            isBordered
                                            as="button"
                                            className="transition-transform"
                                            name={user.name}
                                            size="sm"
                                            radius="md"
                                            src={user.image}
                                        />
                                    </DropdownTrigger>
                                    <DropdownMenu aria-label="Profile Actions" variant="flat">
                                        <DropdownItem key="profile" className="h-14 gap-2" href="/dashboard/profile">
                                            <p className="font-semibold">Connecté en tant que</p>
                                            <p className="font-semibold">{user.name}</p>
                                        </DropdownItem>
                                        <DropdownItem key="dashboard" href="/dashboard" >Dashboard</DropdownItem>
                                        <DropdownItem key="servers" href="/servers">Mes serveurs</DropdownItem>
                                        <DropdownItem key="settings">Mes Paramètres</DropdownItem>
                                        <DropdownItem key="team_settings">Gérer mon Premium</DropdownItem>
                                        <DropdownItem key="logout" color="danger" variant="flat" onClick={() => {
                                            signOut({
                                                callbackUrl: "/",
                                            })
                                            deleteCookie('session');
                                        }}>
                                            Se Déconnecter
                                        </DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            )}
                        </NavbarItem>
                    </div>
                </NavbarContent>

                <NavbarMenu>
                    {loggedIn ? (
                        <div className="text-center">
                            <br />
                            <NavbarMenuItem>
                                Connecté en tant que {user.name} <br />
                            </NavbarMenuItem>

                            <br />
                        </div>

                    ) : (
                        <div className="text-center">
                            <NavbarMenuItem>
                                <Button
                                    variant="ghost"
                                    className="mb-2"
                                    color="warning"
                                    onClick={() => signIn("discord")}
                                >
                                    Connexion à votre compte
                                </Button><br />
                            </NavbarMenuItem>
                        </div>
                    )}
                    <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="default"
                            variant="faded"
                            href="/"
                        >
                            Acceuil
                        </Button>
                    </NavbarMenuItem>
                    {/* <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="default"
                            variant="faded"
                            href="/profile"
                        >
                            Profile
                        </Button>
                    </NavbarMenuItem> */}
                    <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="default"
                            variant="faded"
                            href="/dashboard"
                        >
                            Dashboard
                        </Button>
                    </NavbarMenuItem>
                    <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="default"
                            variant="faded"
                            href="https://discord.gg/Wb7UpyASF9"
                        >
                            Support Discord
                        </Button>
                    </NavbarMenuItem>
                    <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="warning"
                            variant="faded"
                            href="/teams"
                        >
                            Notre Equipe
                        </Button>
                    </NavbarMenuItem>
                    <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="secondary"
                            variant="faded"
                            href="/premium"
                        >
                            Premium ✨
                        </Button>
                    </NavbarMenuItem>
                    <NavbarMenuItem>
                        <Button
                            as={Link}
                            className="w-full"
                            size="lg"
                            color="danger"
                            variant="faded"
                            onClick={() => {
                                signOut({ callbackUrl: "/" });
                                deleteCookie('session');
                            }}
                        >
                            Déconnexion
                        </Button>
                    </NavbarMenuItem>
                </NavbarMenu>
            </Navbar>
            <br /><br /><br /><br /><br />
        </div>
    );
}
