"use client";
import Gradient from "./components/text/main/Amity.jsx"
import Soustitres from "./components/text/main/soustitres.jsx"
import Soutient from "./components/text/main/soutenir.jsx"


export default function HomePage() {
    return (
        <div>
            
            <Gradient />
            <Soustitres />
            <Soutient />
        </div>
    );
}