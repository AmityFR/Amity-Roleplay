import React from "react";
import {
    Card, CardHeader, CardBody,
    Image, Button, Link, Chip
} from "@nextui-org/react";

export default function CardComponent({
    title, description, image, link = false, badge, botIn
}) {
    return (
        <Card className="py-4 w-60 mx-2 flex flex-col items-center">
            <CardHeader className="pb-0 pt-2 px-4 flex-col items-center text-center">
                <small className="text-default-500">{description}</small>
                <p className="text-tiny uppercase font-bold">{title}</p>
            </CardHeader>
            <CardBody className="overflow-visible py-2 flex flex-col items-center">
                <Image
                    alt="Card background"
                    className="object-cover rounded-xl"
                    src={image}
                    width={270}
                />
                <br />
                <Chip color="success" radius="sm" variant="faded">{badge}</Chip>
                <br />
                {botIn ? (
                    <Button as={Link} color="warning" variant="faded" href={`${link}`}>
                        Dashboard
                    </Button>
                ) : (
                    <Button as={Link} color="success" variant="ghost">
                        Ajouter le bot
                    </Button>
                )
                }

            </CardBody>
        </Card >
    )
};