"use client";

import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import getUserServers from '../utils/functions/getUserServers';
import CardComponent from "./CardComponent";
import { Button, Switch, Card, Divider } from '@nextui-org/react';
import axios from 'axios';
import { signIn } from 'next-auth/react';


export default function Servers() {
    const { data: session, status } = useSession();
    const [servers, setServers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [botIn, setBotIn] = useState(true);
    const [adminOnly, setAdminOnly] = useState(false);
    const [ownerOnly, setOwnerOnly] = useState(false);

    useEffect(() => {
        if (status === 'unauthenticated') {
            signIn("discord", { callbackUrl: "/servers" });
        }
        if (status === 'authenticated' && !servers.length) {
            axios.get("/api/guilds/list", {
                params: {
                    accessToken: session.accessToken,
                    id: session.id,
                }
            }).then((res) => {
                setServers(res.data.servers);
                setLoading(false);
            });
        }
    }, [servers, status]);

    if (loading) return <p>Chargement des serveurs et des permissions... Ce processus peux se montrer long.</p>;
    if (!session) return null;


    return (
        <div className='items-center justify-center text-center'>
            <h1>Bienvenue sur votre tableau de bord</h1>
            <p>Connecté en tant que {session.user.name}</p>
            <br /><br />
            <div className='justify-center text-center items-center'>
                <Card
                    variant="faded"
                    className='max-w-[500px] text-center justify-center items-center mx-auto p-5'
                >
                    <Divider orientation='horizontal' className='my-4' />
                    <Switch isSelected={botIn} onValueChange={setBotIn}>
                        Afficher uniquement les serveurs où le bot est présent
                    </Switch>
                    <Divider orientation='horizontal' className='my-4' />
                    <Switch isSelected={adminOnly} onValueChange={setAdminOnly}>
                        Afficher uniquement les serveurs où vous êtes administrateur
                    </Switch>
                    <Divider orientation='horizontal' className='my-4' />
                    <Switch isSelected={ownerOnly} onValueChange={setOwnerOnly}>
                        Afficher uniquement les serveurs où vous êtes propriétaire
                    </Switch>
                    <Divider orientation='horizontal' className='my-4' />
                </Card>
            </div>
            <br /><br />
            <div className="flex justify-center items-center min-h-screen">
                <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 mx-auto">
                    {servers && servers.map((server) => {
                        if (botIn && !server.botIn) return null;
                        if (adminOnly && !server.admin) return null;
                        if (ownerOnly && !server.owner) return null;
                        return (
                            <CardComponent
                                key={server.id}
                                title={server.name}
                                description={server.description}
                                link={server.botIn ? `/dashboard/guilds/${server.id}` : `https://discord.com/oauth2/authorize?client_id=1199327286625832990&permissions=8&redirect_uri=https%3A%2F%2F44t09xkb-3000.euw.devtunnels.ms%2Fservers&scope=bot&guild_id=${server.id}`}
                                image={`https://cdn.discordapp.com/icons/${server.id}/${server.icon}.${server.icon && server.icon.startsWith("a_") ? "gif" : "png"} `}
                                badge={server.owner ? "👑 Propriétaire" : server.admin ? "🚀 Administrateur" : server.staff ? "🎈 Staff" : "👤 Membre"}
                                botIn={server.botIn}
                            />
                        );
                    })}
                </div>
            </div>
        </div>
    );
}