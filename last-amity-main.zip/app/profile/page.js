"use client";

import { useSession, signIn, signOut } from 'next-auth/react';
import { useState } from 'react';


export default function Page() {
    const { data: session } = useSession();
    const [user, setUser] = useState({});



    if (!session) return signIn("discord", { callbackUrl: "/profile" })
    return (
        <>
            <h1 className='text-4xl text-center uppercase' >PROFILE {session.user.name}</h1>
            Not signed in <br />
        </>
    );
}