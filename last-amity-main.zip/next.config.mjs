/** @type {import('next').NextConfig} */
const config = {
    reactStrictMode: true,
    webpack: (config, { isServer }) => {

        if (!isServer) {
            config.resolve = {
                ...config.resolve,
                fallback: {
                    ...config.resolve.fallback,
                    "child_process": false,
                    "fs/promises": false,
                    "dns": false,
                    "net": false,
                    "fs": false,
                    "tls": false,
                    "timers/promises": false,
                },
            };
        }

        config.module.rules.push({
            test: /\.node$/,
            loader: 'node-loader',
        });

        return config;
    },
    experimental: {
        serverActions: {
            allowedOrigins: [
                'localhost:3000',
                '*',
            ]
        },

    },
};

export default config;
